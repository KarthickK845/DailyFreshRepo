package com.handson;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootHandsOnEmployeeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootHandsOnEmployeeApplication.class, args);
	}

}
