package com.handson.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.handson.model.Employee;
import com.handson.repository.EmployeeRepository;

@Service
public class EmployeeService {
	
	@Autowired
	EmployeeRepository repo;
	
	public Employee addEmployee(Employee emp) {
		return this.repo.save(emp);
	}
	
	public List<Employee> getAllEmployees(){
		return this.repo.findAll();
	}
	
	public Employee getEmployeeById(int id) {
		Optional<Employee> opt = this.repo.findById(id);
		if(opt.isPresent())
			return opt.get();
		return null;
	}
	
	public Employee updateEmployee(Employee emp) {
		return this.repo.save(emp);
	}
	
	public boolean deleteEmployee(Employee emp) {
		this.repo.delete(emp);
		return true;
	}
	
	public List<Employee> getEmployeesBySameName(String name){
		return this.repo.findByName(name);
	}
}
