package com.order.dto.request;

import com.order.model.Order;

public class OrderDeleteRequest {
	Order order;

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}
	
	
}
