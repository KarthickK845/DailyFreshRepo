package com.order.ui;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.order.dto.request.OrderAddRequest;
import com.order.dto.request.OrderDeleteRequest;
import com.order.dto.request.OrderUpdateRequest;
import com.order.dto.response.OrderAddResponse;
import com.order.dto.response.OrderDeleteResponse;
import com.order.dto.response.OrderModifyResponse;
import com.order.dto.response.OrderSearchResponse;
import com.order.dto.response.OrderShowAllResponse;
import com.order.exception.OrderNotFoundException;
import com.order.model.Order;
import com.order.service.OrderService;


@RestController
@RequestMapping("/order")
public class OrderController {
	
	@Autowired
	OrderService service;
	
	@PostMapping(value="/add")
	public ResponseEntity<OrderAddResponse> f1(@RequestBody OrderAddRequest request) {
		Order order = this.service.addNewOrder(request.getOrder());
		OrderAddResponse addResponse = new OrderAddResponse();
		addResponse.setStatusCode(201);
		addResponse.setDescription("Order placed successfully");
		addResponse.setOrder(order);
		
		return new ResponseEntity<>(addResponse,HttpStatus.CREATED);
	}
	
	@PutMapping(value="/modify")
	public ResponseEntity<OrderModifyResponse> f2(@RequestBody OrderUpdateRequest request) {
		OrderModifyResponse modifyResponse = new OrderModifyResponse();
		Order order1 = this.service.searchOrder(request.getOrder().getOrderId());
		if(order1 != null) {
			Order order2 = this.service.updateOrder(request.getOrder());
			modifyResponse.setStatusCode(200);
			modifyResponse.setDescription("Order Modified Successfully");
			modifyResponse.setOrder(order2);
			return ResponseEntity.ok(modifyResponse);
		}
		else {
			modifyResponse.setStatusCode(404);
			modifyResponse.setDescription("Order Not Found for Modification");
			modifyResponse.setOrder(null);
			return new ResponseEntity<OrderModifyResponse>(modifyResponse,HttpStatus.NOT_FOUND);
		}	
	}
	
	@GetMapping(value="/find/{id}")
	public ResponseEntity<OrderSearchResponse> f3(@PathVariable(name="id") int id) throws Exception {
		OrderSearchResponse response = new OrderSearchResponse();
		Order order = this.service.searchOrder(id);
		if(order!=null) {
			response.setStatusCode(200);
			response.setDescription("Order details Fetched Successfully");
			response.setOrder(order);
			return new ResponseEntity<OrderSearchResponse>(response, HttpStatus.OK);
		}
		else {
			Exception exception = new OrderNotFoundException("Order Not Found");
			throw exception;
		}
	}
	
	
	@GetMapping(value="/showAll")
	public ResponseEntity<OrderShowAllResponse> f4(){
		List<Order> orders = this.service.getAllOrders();
		OrderShowAllResponse response = new OrderShowAllResponse();
		response.setStatusCode(200);
		response.setDescription("All Orders Fetched");
		response.setOrders(orders);
		return ResponseEntity.ok(response);
	}

	@DeleteMapping(value="/delete")
	public ResponseEntity<OrderDeleteResponse> f5(@RequestBody OrderDeleteRequest request) {
		OrderDeleteResponse response = new OrderDeleteResponse();
		Order order1 = this.service.searchOrder(request.getOrder().getOrderId());
		if(order1!=null)
		{
			try {
				this.service.deleteOrder(request.getOrder());
				response.setStatusCode(200);
				response.setDescription("Order Deleted Successfully");
				response.setDeleteStatus(true);
				return ResponseEntity.ok().body(response);
			}
			catch(Exception e) {
				response.setStatusCode(500);
				response.setDescription("Order Not Deleted");
				response.setDeleteStatus(false);
				return ResponseEntity.internalServerError().body(response);
			}
		}
		else {
			response.setStatusCode(404);
			response.setDescription("Order Not Found");
			response.setDeleteStatus(false);
			return new ResponseEntity<>(response,HttpStatus.NOT_FOUND);
		}
	}
		
	
}
