package com.item.dto.request;

import com.item.model.Item;

public class ItemDeleteRequest {
	Item item;

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}
	
	
}
